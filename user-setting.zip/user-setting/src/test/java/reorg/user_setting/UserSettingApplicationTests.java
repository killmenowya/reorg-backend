package reorg.user_setting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserSettingApplicationTests {

	@Test
	void contextLoads() {
	}

}
